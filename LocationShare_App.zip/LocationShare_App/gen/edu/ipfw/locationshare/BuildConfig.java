/** Automatically generated file. DO NOT MODIFY */
package edu.ipfw.locationshare;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}