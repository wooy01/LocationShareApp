package edu.ipfw.locationshare.serverinterface;

public class ServerInfo {
	public static final String HOST_NAME = "149.164.31.2";		// IAV: 149.164.31.2
	public static final int PORT_NUMBER = 7777;					// IAV: 7777
}
