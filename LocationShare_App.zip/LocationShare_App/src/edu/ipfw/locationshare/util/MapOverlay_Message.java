package edu.ipfw.locationshare.util;

import java.util.ArrayList;
import java.util.List;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.widget.Toast;

import com.google.android.maps.ItemizedOverlay;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;
import edu.ipfw.locationshare.Activity_GoogleMap;
import edu.ipfw.locationshare.R;
import edu.ipfw.locationshare.datamodel.Message;
import edu.ipfw.locationshare.serverinterface.AppClient;

public class MapOverlay_Message extends ItemizedOverlay<OverlayItem> {
	private ArrayList<OverlayItem> mOverlays = new ArrayList<OverlayItem>();
	private Activity_GoogleMap activity;
	private int id;

	
	public MapOverlay_Message(Drawable defaultMarker, Activity_GoogleMap context, int id) {
		super(boundCenter(defaultMarker));
		activity = context;
		this.id = id;
	}

	public ArrayList<OverlayItem> getOverlays() {
		return mOverlays;
	}
	
	public void addOverlay(OverlayItem overlay) {
		mOverlays.add(overlay);
		populate();
	}
	
	public void removeOverlay(OverlayItem overlay) {
		mOverlays.remove(overlay);
		populate();
	}

	public int getID() {
		return id;
	}
	
	public void setID(int id) {
		this.id = id;
	}
	
	@Override
	protected OverlayItem createItem(int i) {
		return mOverlays.get(i);
	}

	
	@Override
	public int size() {
		return mOverlays.size();
	}

	
	@Override
	protected boolean onTap(final int index) {
		// Set the current index
		Activity_GoogleMap.index = index;
				
		// Mark the message as "read"
		Activity_GoogleMap.messages.get(id).setState(Message.STATE_READ);
		
		// Change the color of the marker to show it has been read
		Drawable drawable_red = Activity_GoogleMap.activity.getResources().getDrawable(R.drawable.map_marker_red);
		Activity_GoogleMap.changeMarker(id, drawable_red);
		
		OverlayItem item = mOverlays.get(index);
		
		// Display a dialog to show the message
		AlertDialog.Builder dialog = new AlertDialog.Builder(activity);
		dialog.setIcon(activity.getResources().getDrawable(R.drawable.dialog_icon));
		dialog.setTitle(item.getTitle());
		dialog.setMessage(item.getSnippet());
		
		dialog.setPositiveButton("DELETE", new DialogInterface.OnClickListener() { 
			@Override
			public void onClick(DialogInterface dialog, int which) { 
				dialog.dismiss();
				
				if(Activity_GoogleMap.messages.size() == Activity_GoogleMap.mapView.getOverlays().size()) {
					// Delete the message on the server side
	                //AppClient.getInstance().DeleteMessage(Activity_GoogleMap.messages.get(index).getID());
	                
	                try {
						// Remove the message from the array list of messages
		                Activity_GoogleMap.messages.remove(id);
		                
		                // Remove the message from the map
		                List<Overlay> mapOverlays = Activity_GoogleMap.mapView.getOverlays();
		                mapOverlays.remove(id);
		                mOverlays.remove(mOverlays.get(index));
		                Activity_GoogleMap.mapView.postInvalidate();
		                
		                // Update the message id's
		                for(int i = 0; i < mapOverlays.size(); i++) {
		                	MapOverlay_Message overlay = (MapOverlay_Message)mapOverlays.get(i);
		                	overlay.setID(i);
		                }	                
	                }
    				catch(Exception e) {
    					
    				}
				}
				else {
					// Delete the message on the server side
	                //AppClient.getInstance().DeleteMessage(Activity_GoogleMap.messages.get(index).getID());
	                
					try {
		                // Remove the message from the array list of messages
		                Activity_GoogleMap.messages.remove(id);
		                
		                // Remove the message from the map                
		                List<Overlay> mapOverlays = Activity_GoogleMap.mapView.getOverlays();
		                mapOverlays.remove(id + 1);
		                mOverlays.remove(mOverlays.get(index));
		                Activity_GoogleMap.mapView.postInvalidate();
						
		                // Update the message id's
		                for(int i = 1; i < mapOverlays.size(); i++) {
		                	MapOverlay_Message overlay = (MapOverlay_Message)mapOverlays.get(i);
		                	overlay.setID(i - 1);
		                }
					}
    				catch(Exception e) {
    					
    				}
				}				
			} 
		}); 
		dialog.setNeutralButton("DIRECTIONS", new DialogInterface.OnClickListener() { 
			@Override
			public void onClick(DialogInterface dialog, int which) { 
				dialog.dismiss();
				
				try {
					// Get source lat/lng
					double s_lat = Activity_GoogleMap.whereAmI.getLastFix().getLatitude();
					double s_lng = Activity_GoogleMap.whereAmI.getLastFix().getLongitude();
					
					// Get destination lat/lng
					double d_lat = Activity_GoogleMap.messages.get(index).getLocation().getLatitude();
					double d_lng = Activity_GoogleMap.messages.get(index).getLocation().getLongitude();
					
					// Launch Google navigation
					Intent intent = new Intent(android.content.Intent.ACTION_VIEW, 
							Uri.parse(
									"http://maps.google.com/maps?saddr=" + 
									s_lat + "," + s_lng +
									"&daddr=" +
									d_lat + "," + d_lng
							)
					);
					activity.startActivity(intent);
				}
				catch(Exception e) {
	            	Toast.makeText(activity, "COULD NOT OBTAIN YOUR LOCATION", Toast.LENGTH_LONG).show();
	            }
			} 
		}); 
		
		dialog.show();
		return true;
	}
}
