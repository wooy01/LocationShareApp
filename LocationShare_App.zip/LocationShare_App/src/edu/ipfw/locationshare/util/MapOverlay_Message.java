package edu.ipfw.locationshare.util;

import java.util.ArrayList;
import java.util.List;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.net.Uri;

import com.google.android.maps.ItemizedOverlay;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;
import edu.ipfw.locationshare.Activity_GoogleMap;
import edu.ipfw.locationshare.R;
import edu.ipfw.locationshare.serverinterface.AppClient;

public class MapOverlay_Message extends ItemizedOverlay<OverlayItem> {
	private ArrayList<OverlayItem> mOverlays = new ArrayList<OverlayItem>();
	private Activity_GoogleMap activity;
	private int id;

	
	public MapOverlay_Message(Drawable defaultMarker, Activity_GoogleMap context, int id) {
		super(boundCenter(defaultMarker));
		activity = context;
		this.id = id;
	}

	public ArrayList<OverlayItem> getOverlays() {
		return mOverlays;
	}
	
	public void addOverlay(OverlayItem overlay) {
		mOverlays.add(overlay);
		populate();
	}
	
	public void removeOverlay(OverlayItem overlay) {
		mOverlays.remove(overlay);
		populate();
	}

	
	@Override
	protected OverlayItem createItem(int i) {
		return mOverlays.get(i);
	}

	
	@Override
	public int size() {
		return mOverlays.size();
	}

	
	@Override
	protected boolean onTap(final int index) {
		// Set the current index
		Activity_GoogleMap.index = index;
		
		OverlayItem item = mOverlays.get(index);
		
		// Display a dialog to show the message
		AlertDialog.Builder dialog = new AlertDialog.Builder(activity);
		dialog.setIcon(activity.getResources().getDrawable(R.drawable.dialog_icon));
		dialog.setTitle(item.getTitle());
		dialog.setMessage(item.getSnippet());
		
		dialog.setPositiveButton("DELETE", new DialogInterface.OnClickListener() { 
			@Override
			public void onClick(DialogInterface dialog, int which) { 
				dialog.dismiss();
				
				// Delete the message on the server side
                //AppClient.getInstance().DeleteMessage(Activity_GoogleMap.messages.get(index).getID());
                
                // Remove the message from the array list of messages
                Activity_GoogleMap.messages.remove(id - 1);
                
                // Remove the message from the map                
                List<Overlay> mapOverlays = Activity_GoogleMap.mapView.getOverlays();
                mapOverlays.remove(id);
                mOverlays.remove(mOverlays.get(index));
                Activity_GoogleMap.mapView.postInvalidate();
			} 
		}); 
		dialog.setNeutralButton("DIRECTIONS", new DialogInterface.OnClickListener() { 
			@Override
			public void onClick(DialogInterface dialog, int which) { 
				dialog.dismiss();
				
				// Get source lat/lng
				double s_lat = Activity_GoogleMap.whereAmI.getLastFix().getLatitude();
				double s_lng = Activity_GoogleMap.whereAmI.getLastFix().getLongitude();
				
				// Get destination lat/lng
				double d_lat = Activity_GoogleMap.messages.get(index).getLocation().getLatitude();
				double d_lng = Activity_GoogleMap.messages.get(index).getLocation().getLongitude();
				
				// Launch Google navigation
				Intent intent = new Intent(android.content.Intent.ACTION_VIEW, 
						Uri.parse(
								"http://maps.google.com/maps?saddr=" + 
								s_lat + "," + s_lng +
								"&daddr=" +
								d_lat + "," + d_lng
						)
				);
				activity.startActivity(intent);					
			} 
		}); 
		
		dialog.show();
		return true;
	}
}
