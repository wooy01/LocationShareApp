 package edu.ipfw.locationshare;

import java.util.ArrayList;
import java.util.List;

import com.facebook.Session;
import com.google.android.maps.GeoPoint;
import com.google.android.maps.MapActivity;
import com.google.android.maps.MapController;
import com.google.android.maps.MapView;
import com.google.android.maps.MyLocationOverlay;
import com.google.android.maps.Overlay;
import com.google.android.maps.OverlayItem;

import edu.ipfw.locationshare.datamodel.Message;
import edu.ipfw.locationshare.serverinterface.AppClient;
import edu.ipfw.locationshare.serverinterface.SimpleMessageListener;
import edu.ipfw.locationshare.util.GPS_Manager;
import edu.ipfw.locationshare.util.MapOverlay_Message;

import android.content.Intent;
import android.content.res.Configuration;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

public class Activity_GoogleMap extends MapActivity {
	public static Activity_GoogleMap activity;
	public static ArrayList<Message> messages;
	public static int index;
	public static int id = 0;
	public static int last_centered_index = -1;
	
	public static MapView mapView = null;
    public static MapController mapController = null;
    public static MyLocationOverlay whereAmI = null;
	private int zoomLevel = 13;			
		
	
	/** Called when the activity is first created. */ 
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_googlemap); 
				
		Activity_GoogleMap.activity = this;					
		messages = new ArrayList<Message>();
		
		
		AppClient.newInstance();
				
		// Register a simple logging message listener with the AppClient
        SimpleMessageListener messageListener = new SimpleMessageListener();
        AppClient.getInstance().AddMessageListener(messageListener);
				
		// Get user's name
        String uid = Activity_Start.user.getName();
        AppClient.getInstance().Login(uid);
                
        // Get unread messages
        AppClient.getInstance().GetUnreadMessages();
				
        // Setup the user interface
		setupUI();
	}   

	
	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
	}

	
	private void setupUI() {	
        // Set up the map
		mapView = (MapView) findViewById(R.id.geoMap);
		mapView.setBuiltInZoomControls(true);
		mapView.setSatellite(true);

		mapController = mapView.getController();
		mapController.setZoom(zoomLevel);        // integer from 1-22 (max zoom-in) 

		// Center on users location
		whereAmI = new MyLocationOverlay(getApplicationContext(), mapView);	
		whereAmI.runOnFirstFix(new Runnable() {
			public void run() {
				mapController.setCenter(whereAmI.getMyLocation());
			}	            
		});

		mapView.getOverlays().add(whereAmI);
		mapView.invalidate();	
	}
			
		
	@Override
	protected boolean isLocationDisplayed() {
		return whereAmI.isMyLocationEnabled();
	}

	
	@Override
	protected boolean isRouteDisplayed() {
		return false;
	} 

	
	@Override
	public void onResume() {
		super.onResume();					
		if(!whereAmI.enableMyLocation()) {
			new GPS_Manager(this).enableGPS();   	
		}						
	}

	
	@Override
	protected void onPause() {
		super.onPause();
		whereAmI.disableMyLocation();
	}

	
	@Override
	protected void onDestroy() {
		super.onDestroy();
	}

	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		
		MenuInflater inflater = getMenuInflater();    
		inflater.inflate(R.menu.menu, menu); 		
		return true;
	}

	
	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle item selection    
		switch (item.getItemId()) {		
		case R.id.satellite:				// set map to satellite view
			mapView.setSatellite(true);			
			if (item.isChecked()) 
				item.setChecked(false);    
			else 
				item.setChecked(true);
			break;
		case R.id.normal:					// set map to normal view
			mapView.setSatellite(false);  	
			if (item.isChecked()) 
				item.setChecked(false);    
			else 
				item.setChecked(true);
			break;			
		case R.id.center:					// center map on users location
			try {
        		mapController.animateTo(whereAmI.getMyLocation());
        	}
        	catch(Exception e) {	            		
        	}	
			break;
		case R.id.view_messages:
			// Launch activity to view messages
			startActivity(new Intent(this, Activity_ViewMessages.class));
			break;
		case R.id.create_message:
			// Launch activity to create a message
			startActivity(new Intent(this, Activity_CreateMessage.class));
			break;
		case R.id.logout:
			// Log out of the application
			Session.getActiveSession().closeAndClearTokenInformation();
			Session.setActiveSession(null);
			finish();
			break;
			
		default:        
			return super.onOptionsItemSelected(item);
		}		
		return true;
	}    
	   
		   
	public static void plotMessage(Message message) {
		List<Overlay> mapOverlays = mapView.getOverlays();
		Drawable drawable = Activity_GoogleMap.activity.getResources().getDrawable(R.drawable.map_marker_green);
		MapOverlay_Message itemizedoverlay = new MapOverlay_Message(drawable, Activity_GoogleMap.activity, id);
						
		id++;
		
		// Get the message
		String title = "Message";
		String content = "From: " + message.getSenderUID() + "\n" + 
				"Date: " + message.getSendDT() + "\n\n" + 
				message.getContent();
		
		float lat = message.getLocation().getLatitude();
		float lng = message.getLocation().getLongitude();
		GeoPoint point = new GeoPoint((int)(lat * 1E6), (int)(lng * 1E6));
		OverlayItem overlayitem = new OverlayItem(point, title, content);
		
		itemizedoverlay.addOverlay(overlayitem);			
		
		// Add overlays to the map
		mapOverlays.add(itemizedoverlay);
	}
	
	
	public static void changeMarker(int index, Drawable drawable) {
		List<Overlay> mapOverlays = mapView.getOverlays();
		MapOverlay_Message marker;
		
		try {
			if(mapOverlays.size() == messages.size()) {
				marker = (MapOverlay_Message) mapOverlays.get(index);
			}
			else {
				marker = (MapOverlay_Message) mapOverlays.get(index + 1);
			}
			
			OverlayItem overlay = marker.getItem(0);		
					
			drawable.setBounds(-(drawable.getIntrinsicWidth()/2), -(drawable.getIntrinsicHeight()/2), drawable.getIntrinsicWidth()/2, drawable.getIntrinsicHeight()/2);
			overlay.setMarker(drawable);	
		}
		catch(Exception e) {
			
		}
	}
} 
