package edu.ipfw.locationshare;

import java.util.List;
import java.util.Locale;

import com.google.android.maps.GeoPoint;
import com.google.android.maps.Overlay;

import edu.ipfw.locationshare.datamodel.Message;
import edu.ipfw.locationshare.serverinterface.AppClient;
import edu.ipfw.locationshare.util.MapOverlay_Message;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

public class Activity_ViewMessages extends Activity {
	TextView heading;	
	ListView messageList;	
	Button deleteAll_button;
	Button done_button;
	Activity activity;
	myCustomAdapter adapter;
	
	
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);
		this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
		setContentView(R.layout.activity_viewmessages);
		
		activity = this;
		adapter = new myCustomAdapter(); 
		setUpUI();		
		setupList();
	}
	
	
	@Override
    public void onPause() {
    	super.onPause();  
    }
	
	
	@Override 
	public void onStop() {
		super.onStop();
	}
	
	
	private void setUpUI() {
		heading = (TextView)findViewById(R.id.heading);
		messageList = (ListView)findViewById(R.id.listView1);
		
		done_button = (Button)findViewById(R.id.done);					
		done_button.setOnClickListener(new View.OnClickListener() {			
			@Override
			public void onClick(View v) {	
				finish();					  	
			}			
		});	
		
		deleteAll_button = (Button)findViewById(R.id.delete_button);		
		deleteAll_button.setOnClickListener(new View.OnClickListener() {			
			@Override
			public void onClick(View v) {	
				//Delete all messages for this user
                //AppClient.getInstance().DeleteAllMessages();
                                
                // Remove messages from array list of messages
                for(int i = Activity_GoogleMap.messages.size() - 1; i >= 0; i--) {
                	Activity_GoogleMap.messages.remove(i);
                }                
                
                // Update the message count
        		TextView countTextView = (TextView) findViewById(R.id.countTextView);
        		countTextView.setText("" + Activity_GoogleMap.messages.size());
                
                // Remove messages from list view
                adapter.notifyDataSetChanged();
                
				// Remove messages from map
                List<Overlay> mapOverlays = Activity_GoogleMap.mapView.getOverlays();
                for(int i = mapOverlays.size(); i > 0; i--) {
	                try {
	                    MapOverlay_Message itemizedoverlay = (MapOverlay_Message) mapOverlays.get(i);
	                    itemizedoverlay.getOverlays().remove(itemizedoverlay.getOverlays().get(0));
	                    mapOverlays.remove(itemizedoverlay);
	                    Activity_GoogleMap.mapView.postInvalidate();
	                }
	                catch(Exception e) {
	                	
	                }
                }
			}			
		});	
	}
	
	
	//
	// Display heading for normal screen sizes
	//
	private void setupList() {			
		// Set the heading background color
		heading.setBackgroundColor(Color.LTGRAY);
		
		// Format the message details and display in the row's textview
		String headingText = String.format(Locale.US, "%-6s %-21s %s", "#", "From", "Sent On");
		heading.setText(headingText);
		
		// Display the message count
		TextView countTextView = (TextView) findViewById(R.id.countTextView);
		countTextView.setText("" + Activity_GoogleMap.messages.size());
		
		// Initialize array adapter for list view
		messageList.setAdapter(adapter);		
	}	
	
	
	//
	// Custom ArrayAdapter for list view
	//
	class myCustomAdapter extends BaseAdapter {
		Button colorButton;
		TextView message_info;

		/**
		 * returns the count of elements in the Array that is used to draw the
		 * text in rows
		 * 
		 * @see android.widget.Adapter#getCount()
		 */
		@Override
		public int getCount() {		
			return Activity_GoogleMap.messages.size();			
		}

		/**
		 * @param position
		 *            The position of the row that was clicked (0-n)
		 * @see android.widget.Adapter#getItem(int)
		 */
		@Override
		public String getItem(int position) {
			return null;
		}

		/**
		 * @param position
		 *            The position of the row that was clicked (0-n)
		 * @see android.widget.Adapter#getItemId(int)
		 */
		@Override
		public long getItemId(int position) {
			return position;
		}

		/**
		 * Returns the complete row that the System draws. It is called every
		 * time the System needs to draw a new row; You can control the
		 * appearance of each row inside this function.
		 * 
		 * @param position
		 *            The position of the row that was clicked (0-n)
		 * @param convertView
		 *            The View object of the row that was last created. null if
		 *            its the first row
		 * @param parent
		 *            The ViewGroup object of the parent view
		 * @see android.widget.Adapter#getView(int, android.view.View,
		 *      android.view.ViewGroup)
		 */
		@Override
		public View getView(int position, View convertView, ViewGroup parent) {			
			View row = convertView;
			final int index = position;
			
			final Message message = Activity_GoogleMap.messages.get(index);
						  
			if (row == null) {
				// Getting custom layout to the row
				LayoutInflater inflater = getLayoutInflater();
				row = inflater.inflate(R.layout.queue_row, parent, false);
			}
						
			// Get a reference to the row's text view; find with row.findViewById()
			message_info = (TextView) row.findViewById(R.id.textview);
						
			// Use a monospace font so the data will be aligned properly
			message_info.setTypeface(Typeface.MONOSPACE);
			
			// Format the payment details and display in the row's textview
			String messageDetails = String.format(Locale.US, "%-5d %-20s %s", index+1, message.getSenderUID(), message.getSendDT());
			message_info.setText(messageDetails);
						
			row.setOnClickListener(new OnClickListener() {    
	        	public void onClick(View v) {	
	        		
	        		// Display a dialog to show the message
	        		AlertDialog.Builder dialog = new AlertDialog.Builder(activity);
	        		dialog.setIcon(activity.getResources().getDrawable(R.drawable.dialog_icon));
	        		dialog.setTitle("Message");
	        		dialog.setMessage(
	        				"From: " + message.getSenderUID() + "\n" + 
	        				"Date: " + message.getSendDT() + "\n\n" + 
	        				message.getContent()
	        		);
	        		
	        		Log.d("Map2", "index: " + index);
	        		
	        		dialog.setPositiveButton("DELETE", new DialogInterface.OnClickListener() { 
	        			@Override
	        			public void onClick(DialogInterface dialog, int which) { 
	        				dialog.dismiss();
	        				
	        				// Delete the message on the server side
	                        //AppClient.getInstance().DeleteMessage(Activity_GoogleMap.messages.get(index).getID());
	                        
	                        // Remove message from array list of messages
	                        Activity_GoogleMap.messages.remove(index);
	                        
	                        // Update the message count
	                		TextView countTextView = (TextView) findViewById(R.id.countTextView);
	                		countTextView.setText("" + Activity_GoogleMap.messages.size());
	                        
	                        // Remove message from list view
	                        adapter.notifyDataSetChanged();
	                        	                        	                        
	        				// Remove message from map
	                        List<Overlay> mapOverlays = Activity_GoogleMap.mapView.getOverlays();
	                        try {
		                        MapOverlay_Message itemizedoverlay = (MapOverlay_Message) mapOverlays.get(index+1);
		                        itemizedoverlay.getOverlays().remove(itemizedoverlay.getOverlays().get(0));
		                        mapOverlays.remove(itemizedoverlay);
		                        Activity_GoogleMap.mapView.postInvalidate();
	                        }
	                        catch(Exception e) {
	                        
	                        }	                        
	        			} 
	        		}); 
	        		dialog.setNegativeButton("SHOW ON MAP", new DialogInterface.OnClickListener() { 
	        			@Override
	        			public void onClick(DialogInterface dialog, int which) { 
	        				dialog.dismiss();
	        				
	        				// Center the map on the message location
	        				float lat = message.getLocation().getLatitude();
	        				float lng = message.getLocation().getLongitude();
	        				GeoPoint point = new GeoPoint((int)(lat * 1E6), (int)(lng * 1E6));
	        				
	        				Activity_GoogleMap.mapController.animateTo(point);
	        				finish();
	        			} 
	        		}); 
	        		dialog.setNeutralButton("DIRECTIONS", new DialogInterface.OnClickListener() { 
	        			@Override
	        			public void onClick(DialogInterface dialog, int which) { 
	        				dialog.dismiss();
	        					        				
	        				// Get source lat/lng
	        				double s_lat = Activity_GoogleMap.whereAmI.getLastFix().getLatitude();
	        				double s_lng = Activity_GoogleMap.whereAmI.getLastFix().getLongitude();
	        				
	        				// Get destination lat/lng
	        				double d_lat = message.getLocation().getLatitude();
	        				double d_lng = message.getLocation().getLongitude();
	        				
	        				// Launch Google navigation
	        				Intent intent = new Intent(android.content.Intent.ACTION_VIEW, 
	        						Uri.parse(
	        								"http://maps.google.com/maps?saddr=" + 
	        								s_lat + "," + s_lng +
	        								"&daddr=" +
	        								d_lat + "," + d_lng
	        						)
	        				);
	        				activity.startActivity(intent);	        				
	        			} 
	        		}); 
	        		
	        		dialog.show();
	        	}
	        });
			
			return row; // the row that ListView draws
		}		
	}
}
